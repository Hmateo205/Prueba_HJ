﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Prueba_Progreso_HJ.Models;

namespace Prueba_Progreso_HJ.Data
{
    public class Prueba_Progreso_HJContext : DbContext
    {
        public Prueba_Progreso_HJContext (DbContextOptions<Prueba_Progreso_HJContext> options)
            : base(options)
        {
        }

        public DbSet<Prueba_Progreso_HJ.Models.Estudiante> Estudiante { get; set; } = default!;
        public DbSet<Prueba_Progreso_HJ.Models.Carrera> Carrera { get; set; } = default!;
    }
}
