﻿namespace Prueba_Progreso_HJ.Models
{
    public class Estudiante
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string? Apellido { get; set; }
        public DateTime? Fecha { get; set; }
        public Boolean? Inscrito { get; set; }
        public decimal? Matricula { get; set; }
    }
}
