﻿namespace Prueba_Progreso_HJ.Models
{
    public class Carrera
    {
        public int Id { get; set; }
        public string Nombre_Carrera { get; set; }
        public string? Campus { get; set; }
        public int Semestre { get; set; }
    }
}
